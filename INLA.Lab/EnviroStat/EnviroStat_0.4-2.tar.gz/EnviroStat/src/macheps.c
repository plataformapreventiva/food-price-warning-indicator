#include <float.h>

float feps_() {
  return FLT_EPSILON;
}

double deps_() {
  return DBL_EPSILON;
}
